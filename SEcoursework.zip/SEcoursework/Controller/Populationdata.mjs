

class PopulationController {
  
  constructor(model, view) {
    this.model = model;
    this.view = view;
  }

 
  getPopulationData() {
  
    this.model.fetchPopulationData()
      .then(populationData => {
     
        this.view.displayPopulationData(populationData);
      })
      .catch(error => {
       
        this.view.displayError(error);
      });
  }

 
}



const model = new PopulationModel();
const view = new PopulationView();


const controller = new PopulationController(model, view);


controller.getPopulationData();
