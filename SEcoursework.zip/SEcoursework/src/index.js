/* Import dependencies */
const express = require("express");
const mysql = require("mysql2");


const app = express();
const port = 3000;


app.set("view engine", "pug");
app.set("views", "./views");


app.use(express.static("static"));

console.log(process.env.MODE_ENV);


const db = mysql.createConnection({
    host: process.env.DATABASE_HOST || "localhost",
    user: "user",
    password: "password",
    database: "world",
});


app.get("/", (req, res) => {
    res.render("index",
        { 'title': 'My index page', 'heading': 'My heading' });
});


app.get("/ping", (req, res) => {
    res.send("pong");
});


app.get("/cities", (req, res) => {
    db.execute("SELECT * FROM `city`", (err, rows, fields) => {
        console.log(`/cities: ${rows.length} rows`);
        return res.send(rows);
    });
});

app.get("/city/:id", function (req, res) {
    
    console.log(req, res);
    
    res.send("Id is " + req.params.id);

});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});